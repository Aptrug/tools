import json
from mitmproxy import http, ctx

# ---- CONFIG ----
PATH = "/bookings/services/weekly-limit"
ONLY_SERVICE_ID = "cmkztqx2d000fuckto9dknnv3"  # None = all services

FAKE_RESPONSE = {
	"canBook": True,
	"currentHours": 0,
	"weeklyLimit": 5,
	"remainingBookings": 5,
	"message": "You can book this session. You have 4 bookings remaining this week.",
}
# ----------------


def matches(flow: http.HTTPFlow) -> bool:
	req = flow.request
	if req.method != "GET":
		return False
	if not req.path.split("?")[0].endswith(PATH):
		return False
	if ONLY_SERVICE_ID and req.query.get("service_id") != ONLY_SERVICE_ID:
		return False
	return True


def request(flow: http.HTTPFlow) -> None:
	# Prevent 304 responses (no body to edit)
	if matches(flow):
		flow.request.headers.pop("If-None-Match", None)
		flow.request.headers.pop("If-Modified-Since", None)


def response(flow: http.HTTPFlow) -> None:
	if not matches(flow) or flow.response is None:
		return
	if flow.response.status_code != 200:
		return
	if "json" not in flow.response.headers.get("content-type", ""):
		return

	ctx.log.info(
		f"[fake] replacing response body for {flow.request.pretty_url}"
	)
	flow.response.set_text(json.dumps(FAKE_RESPONSE))
	flow.comment = "replaced with fake response"
